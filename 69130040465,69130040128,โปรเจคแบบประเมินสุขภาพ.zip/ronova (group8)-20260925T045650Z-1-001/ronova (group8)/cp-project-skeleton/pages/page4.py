"""Twenty-question health level assessment page."""

TITLE = "แบบประเมินระดับสุขภาพ"

SCALE = [
    {"value": 0, "label": "ไม่เคย"},
    {"value": 1, "label": "นาน ๆ ครั้ง"},
    {"value": 2, "label": "บางครั้ง"},
    {"value": 3, "label": "บ่อยครั้ง"},
    {"value": 4, "label": "เป็นประจำ"},
]

QUESTIONS = [
    "ฉันรับประทานอาหารครบ 5 หมู่และมีผักหรือผลไม้ในมื้ออาหาร",
    "ฉันดื่มน้ำเปล่าเพียงพอในแต่ละวัน",
    "ฉันหลีกเลี่ยงน้ำหวานและเครื่องดื่มที่มีน้ำตาลสูง",
    "ฉันรับประทานอาหารเป็นเวลาและไม่อดอาหาร",
    "ฉันควบคุมปริมาณอาหารให้เหมาะสมกับร่างกาย",
    "ฉันออกกำลังกายหรือเคลื่อนไหวร่างกายอย่างน้อย 30 นาที",
    "ฉันมีกิจกรรมที่ทำให้หัวใจเต้นเร็วเป็นประจำ",
    "ฉันยืดเหยียดหรือวอร์มอัพก่อนออกกำลังกาย",
    "ฉันนอนหลับอย่างน้อย 7 ชั่วโมงต่อคืน",
    "ฉันตื่นนอนแล้วรู้สึกสดชื่นและพร้อมทำกิจกรรม",
    "ฉันมีเวลาพักระหว่างเรียนหรือทำงานอย่างเหมาะสม",
    "ฉันสามารถจัดการความเครียดของตนเองได้",
    "ฉันมีเวลาทำกิจกรรมที่ชอบหรือผ่อนคลาย",
    "ฉันหลีกเลี่ยงการสูบบุหรี่และควันบุหรี่",
    "ฉันหลีกเลี่ยงการดื่มเครื่องดื่มแอลกอฮอล์",
    "ฉันรักษาความสะอาดของร่างกายและล้างมือสม่ำเสมอ",
    "ฉันตรวจสอบน้ำหนักหรือสังเกตการเปลี่ยนแปลงของร่างกาย",
    "ฉันไปพบแพทย์เมื่อมีอาการผิดปกติที่ไม่หายไป",
    "ฉันมีความสัมพันธ์ที่ดีและสามารถขอความช่วยเหลือเมื่อจำเป็น",
    "ฉันตั้งเป้าหมายและพยายามดูแลสุขภาพของตนเองอย่างต่อเนื่อง",
]


def assess_level(score):
    if score <= 16:
        return "😞 แย่มาก", "ควรเริ่มปรับพฤติกรรมสุขภาพทีละเรื่อง และขอคำแนะนำจากผู้เชี่ยวชาญเมื่อจำเป็น", "very-bad"
    if score <= 32:
        return "🙁 แย่", "ควรเพิ่มการดูแลอาหาร การนอน และการเคลื่อนไหวร่างกายอย่างสม่ำเสมอ", "bad"
    if score <= 48:
        return "😐 ปกติ", "สุขภาพโดยรวมอยู่ในระดับปานกลาง ควรรักษาพฤติกรรมที่ดีและปรับส่วนที่ยังขาด", "normal"
    if score <= 64:
        return "🙂 ดี", "มีพฤติกรรมสุขภาพที่ดี ควรรักษาความสม่ำเสมอและพัฒนาต่อไป", "good"
    return "😄 ดีมาก", "มีวินัยในการดูแลสุขภาพดีมาก รักษาสมดุลและเป็นตัวอย่างที่ดีต่อไป", "very-good"


def build(query=None):
    query = query or {}
    answers = []
    answered = 0
    score = 0

    for index, question in enumerate(QUESTIONS, start=1):
        raw_value = query.get(f"q{index}", "")
        try:
            value = int(raw_value)
            if value < 0 or value > 4:
                value = None
        except (TypeError, ValueError):
            value = None
        if value is not None:
            answered += 1
            score += value
        answers.append(value)

    complete = answered == len(QUESTIONS)
    if complete:
        level, advice, result_class = assess_level(score)
    else:
        level = "ยังไม่ประเมิน"
        advice = f"ตอบคำถามให้ครบทั้ง 20 ข้อ เพื่อดูผลประเมิน (ตอบแล้ว {answered}/20 ข้อ)"
        result_class = "neutral"

    return {
        "questions": QUESTIONS,
        "scale": SCALE,
        "answers": answers,
        "score": score,
        "max_score": len(QUESTIONS) * (len(SCALE) - 1),
        "answered": answered,
        "complete": complete,
        "level": level,
        "advice": advice,
        "result_class": result_class,
    }
