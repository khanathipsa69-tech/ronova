"""Food calorie calculator page."""

TITLE = "คำนวณแคลอรี่อาหาร"

FOODS = [
    {"name": "ข้าวสวย", "calories": 130, "protein": 2.7},
    {"name": "ไก่ย่าง", "calories": 200, "protein": 27.0},
    {"name": "ปลาซาบะย่าง", "calories": 180, "protein": 22.0},
    {"name": "ไข่ไก่", "calories": 155, "protein": 13.0},
    {"name": "ส้มตำ", "calories": 220, "protein": 6.0},
    {"name": "ข้าวโพด", "calories": 96, "protein": 3.5},
    {"name": "กุ้งผัดผัก", "calories": 150, "protein": 18.0},
    {"name": "โยเกิร์ต", "calories": 59, "protein": 10.0},
    {"name": "ข้าวเหนียว", "calories": 135, "protein": 2.8},
    {"name": "ข้าวกล้อง", "calories": 111, "protein": 3.8},
    {"name": "ก๋วยเตี๋ยวเส้นเล็ก", "calories": 150, "protein": 5.0},
    {"name": "ก๋วยเตี๋ยวเส้นใหญ่", "calories": 165, "protein": 5.6},
    {"name": "ก๋วยจั๊บ", "calories": 210, "protein": 12.0},
    {"name": "ราดหน้า", "calories": 270, "protein": 10.0},
    {"name": "ผัดไทย", "calories": 320, "protein": 9.0},
    {"name": "ผัดซีอิ๊ว", "calories": 290, "protein": 11.0},
    {"name": "ข้าวผัดหมู", "calories": 240, "protein": 14.0},
    {"name": "ข้าวผัดไก่", "calories": 235, "protein": 16.0},
    {"name": "กะเพราไก่", "calories": 260, "protein": 18.0},
    {"name": "กะเพราหมู", "calories": 280, "protein": 20.0},
    {"name": "หมูทอด", "calories": 340, "protein": 24.0},
    {"name": "ไก่ทอด", "calories": 310, "protein": 25.0},
    {"name": "ปลาทอด", "calories": 290, "protein": 22.0},
    {"name": "หอยทอด", "calories": 260, "protein": 16.0},
    {"name": "ขนมจีน", "calories": 110, "protein": 4.0},
    {"name": "บะหมี่เกี๊ยว", "calories": 220, "protein": 9.0},
    {"name": "สปาเก็ตตี้คาร์โบเนาะรา", "calories": 350, "protein": 15.0},
    {"name": "สปาเก็ตตี้ขี้เมา", "calories": 330, "protein": 13.0},
    {"name": "แพนเค้ก", "calories": 227, "protein": 5.0},
    {"name": "ครัวซองต์", "calories": 270, "protein": 7.0},
    {"name": "ขนมปังขาว", "calories": 265, "protein": 8.0},
    {"name": "ขนมปังโฮลวีต", "calories": 240, "protein": 11.0},
    {"name": "มะนาวน้ำผึ้ง", "calories": 40, "protein": 0.1},
    {"name": "ชาไทย", "calories": 80, "protein": 0.5},
    {"name": "นมสด", "calories": 60, "protein": 3.2},
    {"name": "นมพร่องมันเนย", "calories": 34, "protein": 3.4},
    {"name": "นมเปรี้ยว", "calories": 52, "protein": 3.5},
    {"name": "โอวัลติน", "calories": 135, "protein": 4.0},
    {"name": "มะม่วงสุก", "calories": 60, "protein": 1.0},
    {"name": "กล้วยน้ำว้า", "calories": 89, "protein": 1.1},
    {"name": "แตงโม", "calories": 30, "protein": 0.6},
    {"name": "ทุเรียน", "calories": 147, "protein": 1.9},
    {"name": "ส้ม", "calories": 47, "protein": 0.9},
    {"name": "กล้วยหอม", "calories": 89, "protein": 1.2},
    {"name": "มะละกอสุก", "calories": 39, "protein": 0.6},
    {"name": "สตรอเบอร์รี่", "calories": 32, "protein": 0.7},
    {"name": "สัปปะรด", "calories": 50, "protein": 0.5},
    {"name": "แอปเปิ้ล", "calories": 52, "protein": 0.3},
    {"name": "องุ่น", "calories": 69, "protein": 0.6},
    {"name": "มะเขือเทศ", "calories": 18, "protein": 0.9},
    {"name": "ผักกาดหอม", "calories": 15, "protein": 1.2},
    {"name": "ผักบุ้ง", "calories": 22, "protein": 2.8},
    {"name": "กะหล่ำปลี", "calories": 25, "protein": 1.3},
    {"name": "บรอกโคลี", "calories": 34, "protein": 2.8},
    {"name": "แครอท", "calories": 41, "protein": 0.9},
    {"name": "มันฝรั่งทอด", "calories": 312, "protein": 3.4},
    {"name": "มันฝรั่งต้ม", "calories": 77, "protein": 2.0},
    {"name": "กุ้งสด", "calories": 99, "protein": 24.0},
    {"name": "ปลาหมึก", "calories": 82, "protein": 18.0},
    {"name": "ปูม้าลาย", "calories": 95, "protein": 18.7},
    {"name": "หอยนางรม", "calories": 50, "protein": 11.0},
    {"name": "หอยแมลงภู่", "calories": 82, "protein": 14.0},
    {"name": "ปลาแซลมอน", "calories": 208, "protein": 20.0},
    {"name": "กบช้ำ", "calories": 120, "protein": 17.0},
    {"name": "หมูสามชั้น", "calories": 500, "protein": 15.0},
    {"name": "หมูสับ", "calories": 180, "protein": 20.0},
    {"name": "เนื้อวัว", "calories": 250, "protein": 26.0},
    {"name": "เนื้อไก่ไม่ติดหนัง", "calories": 165, "protein": 31.0},
    {"name": "กุ้งก้ามกราม", "calories": 120, "protein": 24.0},
    {"name": "ปลาทู", "calories": 145, "protein": 21.0},
    {"name": "ปลานิล", "calories": 150, "protein": 23.0},
    {"name": "ปลาช่อน", "calories": 170, "protein": 20.0},
    {"name": "ไข่ดาว", "calories": 74, "protein": 6.3},
    {"name": "ไข่ขาว", "calories": 52, "protein": 11.0},
    {"name": "ไข่แดง", "calories": 322, "protein": 16.0},
    {"name": "ซีเรียล", "calories": 390, "protein": 8.0},
    {"name": "โจ๊ก", "calories": 90, "protein": 2.0},
    {"name": "กุนเชียง", "calories": 350, "protein": 12.0},
    {"name": "บัวลอย", "calories": 180, "protein": 3.5},
    {"name": "ทองม้วน", "calories": 140, "protein": 2.0},
    {"name": "น้ำเต้าหู้ยี้", "calories": 110, "protein": 5.0},
    {"name": "เชอรี่", "calories": 50, "protein": 1.0},
    {"name": "บลูเบอร์รี", "calories": 57, "protein": 0.7},
    {"name": "กะทิ", "calories": 190, "protein": 1.3},
    {"name": "หอมใหญ่", "calories": 40, "protein": 1.1},
    {"name": "กระเทียม", "calories": 149, "protein": 6.4},
    {"name": "พริกชี้ฟ้า", "calories": 40, "protein": 1.9},
    {"name": "ถั่วเขียวต้มน้ำ", "calories": 116, "protein": 8.0},
    {"name": "ถั่วลิสง", "calories": 567, "protein": 25.0},
    {"name": "อัลมอนด์", "calories": 579, "protein": 21.0},
    {"name": "เมล็ดทานตะวัน", "calories": 584, "protein": 23.0},
    {"name": "ข้าวโอ๊ต", "calories": 389, "protein": 16.0},
    {"name": "มะพร้าวอ่อน", "calories": 50, "protein": 1.2},
    {"name": "ไส้กรอก", "calories": 290, "protein": 12.0},
    {"name": "ชิ้นพายไก่", "calories": 240, "protein": 20.0},
    {"name": "เบอร์เกอร์ไก่", "calories": 250, "protein": 16.0},
    {"name": "เบอร์เกอร์โฮมเมด", "calories": 300, "protein": 18.0},
    {"name": "พาสต้าแป้ง", "calories": 344, "protein": 12.0},
    {"name": "ขนมครก", "calories": 170, "protein": 3.0},
    {"name": "ก๋วยเตี๋ยวคั่วไก่", "calories": 320, "protein": 18.0},
    {"name": "ยำวุ้นเส้น", "calories": 180, "protein": 7.0},
    {"name": "ไก่ย่างเกาหลี", "calories": 230, "protein": 26.0},
    {"name": "ข้าวมันไก่", "calories": 330, "protein": 16.0},
    {"name": "โจ๊กใส่ไข่", "calories": 130, "protein": 6.0},
    {"name": "ปาท่องโก๋", "calories": 330, "protein": 6.0},
    {"name": "กะหรี่ปั๊บ", "calories": 260, "protein": 11.0},
    {"name": "สลัดผัก", "calories": 70, "protein": 3.5},
    {"name": "สลัดทูน่า", "calories": 150, "protein": 18.0},
    {"name": "ซุปมิโสะ", "calories": 90, "protein": 4.0},
    {"name": "ซุปหน่อไม้", "calories": 55, "protein": 2.5},
    {"name": "ผัดผักรวม", "calories": 85, "protein": 4.0},
    {"name": "ไก่ผัดมะเขือเทศ", "calories": 210, "protein": 22.0},
    {"name": "หมูผัดกะเพรา", "calories": 260, "protein": 22.0}
]


def build(query=None):
    query = query or {}
    food_name = query.get("food", "ข้าวสวย")
    grams = query.get("grams", "100")

    food = FOODS[0]
    for item in FOODS:
        if item["name"] == food_name:
            food = item
            break

    try:
        grams_value = float(grams)
    except (TypeError, ValueError):
        grams_value = 100.0

    grams_value = max(0.0, grams_value)

    calories = (food["calories"] * grams_value) / 100
    protein = (food["protein"] * grams_value) / 100

    max_calories = max(item["calories"] for item in FOODS)
    max_protein = max(item["protein"] for item in FOODS)
    chart_calories_max = max(500.0, calories)
    chart_protein_max = max(40.0, protein)
    calories_pct = min(100.0, (calories / chart_calories_max) * 100)
    protein_pct = min(100.0, (protein / chart_protein_max) * 100)

    return {
        "foods": FOODS,
        "food": food,
        "selected_food": food_name,
        "grams": grams_value,
        "calories": calories,
        "protein": protein,
        "max_calories": max_calories,
        "max_protein": max_protein,
        "chart_calories_max": chart_calories_max,
        "chart_protein_max": chart_protein_max,
        "calories_pct": calories_pct,
        "protein_pct": protein_pct,
    }
