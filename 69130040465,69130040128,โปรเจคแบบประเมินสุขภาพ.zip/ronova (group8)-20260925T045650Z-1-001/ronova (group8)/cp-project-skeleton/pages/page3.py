"""Weight goal planner page."""

import models

TITLE = "วางแผนเป้าหมายน้ำหนัก"

GOAL_OPTIONS = [
    {"value": "lose", "label": "ลดน้ำหนัก"},
    {"value": "gain", "label": "เพิ่มน้ำหนัก"},
]

WEEKLY_PLANS = {
    "lose": [
        {"day": "จันทร์", "focus": "คาร์ดิโอ", "exercise": "เดินเร็ว 10 นาที + วิ่งเหยาะ 20 นาที", "minutes": 30},
        {"day": "อังคาร", "focus": "เวทช่วงบน", "exercise": "วิดพื้น, ดึงยางยืด, แพลงก์ อย่างละ 3 เซต", "minutes": 30},
        {"day": "พุธ", "focus": "คาร์ดิโอเบา", "exercise": "ปั่นจักรยานหรือเดินเร็วต่อเนื่อง", "minutes": 30},
        {"day": "พฤหัสบดี", "focus": "เวทช่วงล่าง", "exercise": "สควอต, ลันจ์, สะพานก้น อย่างละ 3 เซต", "minutes": 35},
        {"day": "ศุกร์", "focus": "คาร์ดิโอ", "exercise": "วิ่งสลับเดิน 5 รอบ + ยืดเหยียด", "minutes": 30},
        {"day": "เสาร์", "focus": "กิจกรรมที่ชอบ", "exercise": "ว่ายน้ำ เต้น หรือเดินเล่นในระดับปานกลาง", "minutes": 40},
        {"day": "อาทิตย์", "focus": "พักฟื้น", "exercise": "ยืดเหยียดเบา ๆ และเดินสบาย ๆ", "minutes": 20},
    ],
    "gain": [
        {"day": "จันทร์", "focus": "อกและแขน", "exercise": "วิดพื้น, ดันอก, ไบเซปเคิร์ล อย่างละ 3 เซต", "minutes": 40},
        {"day": "อังคาร", "focus": "พักฟื้น", "exercise": "เดินสบาย ๆ และยืดกล้ามเนื้อ", "minutes": 20},
        {"day": "พุธ", "focus": "ขาและสะโพก", "exercise": "สควอต, ลันจ์, เดดลิฟต์น้ำหนักเบา อย่างละ 3 เซต", "minutes": 40},
        {"day": "พฤหัสบดี", "focus": "หลังและไหล่", "exercise": "ดึงยางยืด, โรว์, โชลเดอร์เพรส อย่างละ 3 เซต", "minutes": 40},
        {"day": "ศุกร์", "focus": "พักฟื้น", "exercise": "เดินเบา ๆ และยืดกล้ามเนื้อ", "minutes": 20},
        {"day": "เสาร์", "focus": "เวททั้งตัว", "exercise": "สควอต, วิดพื้น, โรว์ และแพลงก์ 3 รอบ", "minutes": 40},
        {"day": "อาทิตย์", "focus": "พัก", "exercise": "พักผ่อนให้เพียงพอและยืดเหยียดเบา ๆ", "minutes": 15},
    ],
}

FOOD_ADVICE = {
    "lose": [
        "จัดจานให้มีผักครึ่งหนึ่ง โปรตีนไม่ติดมันหนึ่งส่วน และข้าวหรือแป้งไม่ขัดสีหนึ่งส่วน",
        "เลือกน้ำเปล่า ลดน้ำหวาน ของทอด และขนมที่มีน้ำตาลสูง",
        "กินให้ครบมื้อและควบคุมปริมาณ ไม่อดอาหารจนหิวมาก",
    ],
    "gain": [
        "เพิ่มพลังงานจากอาหารคุณภาพ เช่น ข้าวกล้อง ไข่ นม ถั่ว อะโวคาโด และปลา",
        "ให้มีโปรตีนทุกมื้อ และเพิ่มอาหารว่างที่มีโปรตีนระหว่างมื้อ",
        "ดื่มน้ำให้เพียงพอและพักผ่อน 7-9 ชั่วโมง เพื่อช่วยฟื้นฟูกล้ามเนื้อ",
    ],
}


def build(query=None):
    query = query or {}
    goal = next(
        (option["value"] for option in GOAL_OPTIONS if option["value"] == query.get("goal")),
        "lose",
    )

    weight = query.get("weight", "")
    change = query.get("change", "")
    weight_value = None
    change_value = None
    target_weight = None
    error = ""

    try:
        if weight not in ("", None):
            weight_value = float(weight)
        if change not in ("", None):
            change_value = float(change)
        if weight_value is not None and change_value is not None:
            if weight_value <= 0 or change_value <= 0:
                error = "กรอกน้ำหนักและจำนวนกิโลกรัมเป็นค่ามากกว่า 0"
                weight_value = None
                change_value = None
            else:
                goal_model = models.HealthGoal(goal, weight_value, change_value)
                target_weight = goal_model.target_weight()
                if target_weight <= 0:
                    error = "น้ำหนักเป้าหมายต้องมากกว่า 0 กิโลกรัม"
                    target_weight = None
    except (TypeError, ValueError):
        error = "กรุณากรอกข้อมูลเป็นตัวเลข"

    plan = [dict(item) for item in WEEKLY_PLANS[goal]]
    if change_value is None:
        change_level = "รอข้อมูลเป้าหมาย"
        schedule_note = "กรอกน้ำหนักและจำนวนกิโลกรัมที่ต้องการเปลี่ยน เพื่อจัดเวลาที่เหมาะสมให้คุณ"
    elif change_value <= 3:
        change_level = "เป้าหมายเริ่มต้น"
        schedule_note = "จัดตารางระดับเริ่มต้น เน้นทำต่อเนื่องและพักให้เพียงพอ"
        for item in plan:
            item["minutes"] = max(15, item["minutes"] - 5)
    elif change_value <= 7:
        change_level = "เป้าหมายปานกลาง"
        schedule_note = "จัดตารางระดับปานกลางสำหรับการเปลี่ยนแปลงอย่างค่อยเป็นค่อยไป"
    else:
        change_level = "เป้าหมายมากกว่า 7 กก."
        schedule_note = "จัดตารางเพิ่มเวลาเล็กน้อย โดยยังคงมีวันพักเพื่อป้องกันการฝืนร่างกาย"
        for item in plan:
            if "พัก" not in item["focus"]:
                item["minutes"] = min(50, item["minutes"] + 5)

    return {
        "goal": goal,
        "goal_options": GOAL_OPTIONS,
        "weight": weight,
        "change": change,
        "weight_value": weight_value,
        "change_value": change_value,
        "target_weight": target_weight,
        "error": error,
        "plan": plan,
        "food_advice": FOOD_ADVICE[goal],
        "goal_label": "เพิ่มน้ำหนัก" if goal == "gain" else "ลดน้ำหนัก",
        "change_level": change_level,
        "schedule_note": schedule_note,
    }
