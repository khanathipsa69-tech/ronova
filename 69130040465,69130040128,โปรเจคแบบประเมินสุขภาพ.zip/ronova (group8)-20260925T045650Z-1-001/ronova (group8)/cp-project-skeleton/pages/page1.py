"""BMI calculator page."""

TITLE = "คำนวณค่า BMI"


def build(query=None):
    query = query or {}

    age = query.get("age", "")
    weight = query.get("weight", "")
    height = query.get("height", "")

    bmi = None
    result = "กรอกข้อมูลเพื่อคำนวณ"
    result_class = "neutral"
    detail = "กรุณากรอกอายุ น้ำหนัก และส่วนสูงเพื่อดูผลลัพธ์"

    try:
        if age not in ("", None) and weight not in ("", None) and height not in ("", None):
            age_value = float(age)
            weight_value = float(weight)
            height_value = float(height)

            if age_value > 0 and weight_value > 0 and height_value > 0:
                height_m = height_value / 100
                bmi = weight_value / (height_m * height_m)

                if bmi < 18.5:
                    result = "ต่ำกว่าเกณฑ์"
                    result_class = "low"
                    detail = "น้ำหนักน้อยกว่ามาตรฐาน ควรรับประทานอาหารให้เพียงพอและออกกำลังกายอย่างเหมาะสม"
                elif bmi < 23:
                    result = "เกณฑ์มาตรฐาน"
                    result_class = "normal"
                    detail = "น้ำหนักอยู่ในระดับที่เหมาะสม ควรดูแลสุขภาพต่อไป"
                else:
                    result = "เกินเกณฑ์"
                    result_class = "high"
                    detail = "น้ำหนักเกินมาตรฐาน ควรปรับพฤติกรรมและออกกำลังกายสม่ำเสมอ"
    except (TypeError, ValueError):
        bmi = None
        result = "กรุณากรอกข้อมูลให้ถูกต้อง"
        result_class = "neutral"
        detail = "กรอกเป็นตัวเลขเท่านั้น"

    return {
        "age": age,
        "weight": weight,
        "height": height,
        "bmi": bmi,
        "result": result,
        "result_class": result_class,
        "detail": detail,
    }
