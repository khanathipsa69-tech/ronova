"""Small domain models used by the health assessment pages."""


class HealthGoal:
    """Represent a user's current weight and desired change."""

    def __init__(self, goal, current_weight, change):
        self.goal = goal
        self.current_weight = current_weight
        self.change = change

    def target_weight(self):
        if self.current_weight is None or self.change is None:
            return None
        if self.goal == "gain":
            return self.current_weight + self.change
        return self.current_weight - self.change

    def describe(self):
        target = self.target_weight()
        if target is None:
            return "ยังไม่ได้กำหนดเป้าหมาย"
        action = "เพิ่ม" if self.goal == "gain" else "ลด"
        return f"{action}น้ำหนัก {self.change:g} กก. ไปสู่ {target:g} กก."
